
<!DOCTYPE html>
<HTMI>
<head>
<title  style="font-size: large;">Resume แนะนำตัว</title>
<meta charset="utf-8">
</head>
<body style="background-color: beige;">
<h1 style="color: rgb(84, 84, 226);">Resume แนะนำตัว </h1>
    <img src="อังเด.jpg" alt="AUNG" width="360" height="350">
<h1  style="color: darkorange;">ชื่อ นาย รัฐภูมิ เบียดนอก</h1>
<h2  style="color: rgb(63, 48, 21);">ชื่อเล่น อังเดย์</h2>
<h3  style="color: steelblue;">วัน/เดือน/ปี เกิด 27 พฤษภาคม พ.ศ.2548</div></h3>
<h3  style="color: rgb(15, 233, 99);">ที่อยู่ 92 หมู่ 6 บ.หนองคู ต.หนองบัวบาน อ.จัตุรัส จ.ชัยภูมิ 36130</h4>
<h1  style="color: darkgoldenrod;">ช่องทางติดต่อ</h1>
<h2  style="color: darkblue;">Facebook:Ratthaphum beadnok</h2>
<h2  style="color: green;">Line Id:mjay123</h2>
<h2  style="color: mediumslateblue;">Cell Phone:0635123347</h2>
<h3  style="color: chocolate;">เกี่ยวกับฉัน</h3>
<h4  style="color: lightcoral;">ชื่อเล่น อังเดย์ ส่วนสูง 178 ซม. น้ำหนัก 52 กก.</h4>
<h1  style="color: mediumvioletred;">ข้อมูลส่วนตัว</h1>
<h2  style="color: rgb(35, 116, 136);">ชื่อบิดา นาย เพลิน เบียดนอก อายุ 45 ปี</h2>
<h2  style="color: rgb(117, 33, 33);">อาชีพ พนักงานขนส่ง เบอร์โทร -</h2>
<h2  style="color: darkseagreen;">ชื่อมารดา นาง นัธทมน จันทรวิจิตร อายุ 43 ปี</h2>
<h2  style="color: mediumturquoise;">อาชีพ พนักงานโรงงาน เบอร์โทร - </h2>

<h1  style="color: rgb(13, 124, 168);">ประวัติการศึกษา</h1>
<h2  style="color: salmon;">จบประถมจาก โรงเรียนชุมชนบัวบานสามัคคี</h2>
<h2  style="color: mediumorchid;">จบมัธยมจาก โรงเรียนหนองบัวบานวิทยา</h2>

<h1  style="color: teal;">คติประจำใจ</h1>
<h2  style="color: royalblue;">ความพยายามจะไม่มีวันทรยศตัวเอง</h2>
 
<h1  style="color: palevioletred;">งานอดิเรก</h1>
<h2  style="color: rgb(196, 98, 33);"> นอน เล่นเกม ทำอาหาร อ่านหนังสือ </h2>

<h1  style="color: gray;">นักศึกษาเลือกเรียนสาขานี้เพราะอะไร ? เรียนจบอยากทำอาชีพอะไร ? </h1>
<h2  style="color: firebrick;"> เพราะอยากศึกษาเกี่ยวกับโค้ด เรียนจบอยากทำงานเป็นโปรแกรมเมอร์ </h2>
</body>
</HTMI>
Resume.html
กำลังแสดง Resume.html