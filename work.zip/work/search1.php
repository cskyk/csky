<?php /* *** No Copyright for Education (Free to Use and Edit) *** */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Search Employee Data</title>
    <style>
         body, html {
            height: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
        }
        body{
            display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: url(9r.jpg) no-repeat;
    background-size: cover;
    background-position: center;
}

        .container {
            width: 420px;
        background: transparent;
        border: 2px solid rgba(255, 255, 255, .2);
        backdrop-filter: blur(9px);
        color: #fff;
        border-radius: 12px;
        padding: 30px 40px;
        }
        table {
            margin: 0 auto;
            border-collapse: collapse;
        }
        td {
            padding: 10px;
        }
        input[type="submit"] {
            margin-top: 10px;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>ค้นหารายชื่อนักศึกษา</h1>
        <form action="searchdata1.php" method="GET" name="Employee">
            <table>
                <div class="wrapper">
                    <td>ใส่ชื่อนักศึกษา:</td>
                    <div class="input-box">
                    <td><input type="text" name="keyword"></td>
    </div>
    </div>
            </table>
            <br>
            <div style="text-align: center;">
            <input  type="submit" value="Search Data">
  </div>
        </form>
    </div>
</body>

</html>
