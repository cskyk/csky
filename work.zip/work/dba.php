<?php
$dsn = 'mysql:host=localhost;dbname=my_database';  // เปลี่ยน my_database เป็นชื่อฐานข้อมูลที่คุณใช้งาน
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
    exit();
}
?>
