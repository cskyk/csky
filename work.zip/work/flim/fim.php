<!DOCTYPE html>
<html>
<title>สวัสดีจ้า</title>
<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body style="background-image: url(m.jpg);">
    <h1 style="color:#E1AFD1;">ประวัติส่วนตัว</h1>
<img src="ขีเแอค.jpg.jpg"Trulli" width="150" height="200">
<h2 style="color:#7469B6;">นาย รัฐภูมิ คนเพียร ชื่อเล่น ฟิล์ม</h2>
<h2 style="color:#AD88C6;">อายุ18ขวบ แผนกIt ห้องD5</h2>
<h2 style="color:#E1AFD1;">ที่อยู่:113หมู่10 บ้านหนองหอย ตำบลกุดชุมแสง อำเภอหนองบัวแดง จังหวัดชัยภูมิ</h2>
<h2 style="color:#7469B6;">เกี่ยวกับฉัน:ชื่อฟิล์มเรียกฟิล์มนั่นแหละ ชอบเล่นเกม และชอบนอนเป็นพิเศษ</h2>
<h2 style="color:#7469B6;">กรุ๊บเลือด:ไม่ทราบ</h2>
<h2 style="color:#AD88C6;">วัน/เดือน/ปีเกิด: 31/5/2548</h2>
<h1 style="color:#E1AFD1;">ช่องทางติดต่อ :</h1>
<h2 style="color:#AD88C6;">FB:Rattaphun konpiean</h2>
<h2 style="color:#AD88C6;"> Gmail: Fim36210@gmail.com</h2>
<h2 style="color:#7469B6;">tel:0653150450</h2>
<h1 style="color:#E1AFD1;">ชื่อบิดา มารดา :</h1>
<h2 style="color:#7469B6;">ชื่อบิดา นายโส คนเพียร อาชีพ:รับจ้าง อายุ:37 เบอร์ 0929691564</h2>
<h2 style="color:#7469B6;">ชื่อมารดา นางสาวประนอม สุนิพรม อาชีพ:รับจ้าง อายุ:40 เบอร์ 0929691564</h2>
<h1 style="color:#E1AFD1;">ประวัติการศึกษา</h1>
<h2 style="color:#7469B6;">จบประถมศึกษาจาก โรงเรียนบ้านหนองหอย</h2>
<h2 style="color:#7469B6;">จบมัธยมศึกษาตอนต้นจาก โรงเรียนหนองบัวแดงวิทยา</h2>
<h2 style="color:#AD88C6;">จบมัธยมศึกษาตอนปลายจาก โรงเรียนหนองบัวแดงวิทยา</h2>
<h1 style="color:#E1AFD1;">คติประจำใจ</h1>
<h2 style="color:#7469B6;">ความอดทนจะเปลี่ยนคนให้แข็งแกร่ง</h2>
<h1 style="color:#E1AFD1;">งานอดิเรก</h1>
<h2 style="color:#7469B6;">นอน</h2>
<h1 style="color:#E1AFD1;">เลือกสาขานี้เพราะอะไร</h1>
<h2 style="color:#7469B6;">อยากทำงานสายไอที</h2>

</body>
</html>
