<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>สวัสดีจ้า - Resume</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url(4r.jpg) no-repeat center center fixed;
            background-size: cover;
        }
        .container {
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            color: #2A629A;
        }
        h1 {
            font-size: 2rem;
            margin-bottom: 20px;
        }
        .profile-pic {
            border-radius: 50%;
            margin-bottom: 20px;
        }
        .section-title {
            margin-top: 30px;
            margin-bottom: 15px;
            color: #FF2E2E;
        }
    </style>
</head>
<body>
    <div class="container text-center">
        <!-- Profile Picture and Basic Information -->
        <h1 class="section-title">Resume</h1>
        <img src="gg Gz.jpg" alt="Profile Picture" class="profile-pic" width="150" height="200">
        <h2>ชื่อ: นพนัฐ มาลา</h2>
        <h2>ชื่อเล่น: นัฐ</h2>
        <h2>กรุ๊ปเลือด: B</h2>
        <h2>ว/ด/ป เกิด: 04/01/2004</h2>
        <h2>ที่อยู่: 172/1 หมู่ 11 บ้านโนนทอง ตำบลบ้านกอก อำเภอจัตุรัส จังหวัดชัยภูมิ</h2>
        <h2>เกี่ยวกับฉัน: ง่วงตลอดเวลา</h2>

        <!-- Contact Information -->
        <h1 class="section-title">ช่องทางติดต่อ</h1>
        <h2>Line: nut31178</h2>
        <h2>เบอร์: 0638397659</h2>
        <h2>Facebook: Noppanut Mala</h2>
        <h2>E-mail: noppanutkll@gmail.com</h2>

        <!-- Family Information -->
        <h1 class="section-title">ข้อมูลส่วนตัว</h1>
        <h2>ชื่อบิดา: นายรักษ์ มาลา อายุ: 45</h2>
        <h2>อาชีพ: ชาวนา เบอร์: 083-604-3731</h2>
        <h2>ชื่อมารดา: นางขจิต มาลา อายุ: 43</h2>
        <h2>อาชีพ: แม่ครัว เบอร์: 061-896-2829</h2>

        <!-- Education -->
        <h1 class="section-title">ประวัติการศึกษา</h1>
        <h2>โรงเรียนศรีเทพบาล</h2>
        <h2>โรงเรียนจัตุรัสวิยาคาร</h2>
        <h2>โรงเรียนกองทัพบกอุปถัมภ์ ช่างกล ขส.ทบ</h2>

        <!-- Motto and Hobbies -->
        <h1 class="section-title">คติประจำใจ</h1>
        <h2>gg Gz</h2>

        <h1 class="section-title">งานอดิเรก</h1>
        <h2>เล่นหมากรุก บาร์เทนเดอร์</h2>

        <!-- Career Interest -->
        <h1 class="section-title">นักศึกษาเลือกเรียนสาขานี้เพราะอะไร? เรียนจบอยากทำอาชีพอะไร?</h1>
        <h2>เลือกสาขา IT เพราะชอบ จบไปอยากทำอาชีพโปรแกรมเมอร์</h2>
    </div>
</body>
</html>
