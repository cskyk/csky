<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>สวัสดีจ้า - Resume</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
            min-height: 100vh;
            background: url('4r.jpg') no-repeat center center fixed;
            background-size: cover;
            background-blend-mode: overlay;
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
        }
        .nav-tabs .nav-link.active {
            background-color: #FF2E2E;
            color: white;
        }
        .profile-pic {
            border-radius: 50%;
            margin-bottom: 20px;
        }

        h5{
            color: #ff2e2e;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <!-- Nav Tabs -->
        <ul class="nav nav-tabs justify-content-center" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">ข้อมูลส่วนตัว</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">ช่องทางติดต่อ</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="family-tab" data-bs-toggle="tab" data-bs-target="#family" type="button" role="tab" aria-controls="family" aria-selected="false">ข้อมูลครอบครัว</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="education-tab" data-bs-toggle="tab" data-bs-target="#education" type="button" role="tab" aria-controls="education" aria-selected="false">ประวัติการศึกษา</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="hobbies-tab" data-bs-toggle="tab" data-bs-target="#hobbies" type="button" role="tab" aria-controls="hobbies" aria-selected="false">คติและงานอดิเรก</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="career-tab" data-bs-toggle="tab" data-bs-target="#career" type="button" role="tab" aria-controls="career" aria-selected="false">เป้าหมายอาชีพ</button>
            </li>
        </ul>

        <!-- Tab Content -->
        <div class="tab-content mt-4" id="myTabContent">
            <!-- Personal Information -->
            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                <div class="text-center">
                    <img src="gg Gz.jpg" alt="Profile Picture of Noppanut Mala" class="profile-pic img-fluid" width="150" height="200">
                    <h2>ชื่อ: นพนัฐ มาลา</h2>
                    <p>ชื่อเล่น: นัฐ</p>
                    <p>กรุ๊ปเลือด: B</p>
                    <p>ว/ด/ป เกิด: 04/01/2004</p>
                    <p>ที่อยู่: 172/1 หมู่ 11 บ้านโนนทอง ตำบลบ้านกอก อำเภอจัตุรัส จังหวัดชัยภูมิ</p>
                    <p>เกี่ยวกับฉัน: ง่วงตลอดเวลา</p>
                </div>
            </div>
            
            <!-- Contact Information -->
            <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                <div class="row">
                    <div class="col-md-6">
                        <h5>ช่องทางติดต่อ</h5>
                        <p>Line: <a href="#">nut31178</a></p>
                        <p>เบอร์: <a href="tel:0638397659">0638397659</a></p>
                        <p>Facebook: <a href="https://www.facebook.com/killss.tvzz/" target="_blank">Noppanut Mala</a></p>
                        <p>Email: <a href="mailto:noppanutkll@gmail.com">noppanutkll@gmail.com</a></p>
                    </div>
                </div>
            </div>
            
            <!-- Family Information -->
            <div class="tab-pane fade" id="family" role="tabpanel" aria-labelledby="family-tab">
                <div class="row">
                    <div class="col-md-6">
                        <h5>ข้อมูลครอบครัว</h5>
                        <p>ชื่อบิดา: นายรักษ์ มาลา อายุ: 45</p>
                        <p>อาชีพ: ชาวนา เบอร์: 083-604-3731</p>
                    <div class="col-md-6">
                        <p>ชื่อมารดา: นางขจิต มาลา อายุ: 43</p>
                        <p>อาชีพ: แม่ครัว เบอร์: 061-896-2829</p>
                    </div>
                    </div>
                </div>
            </div>

            <!-- Education -->
            <div class="tab-pane fade" id="education" role="tabpanel" aria-labelledby="education-tab">
                <h5>ประวัติการศึกษา</h5>
                <ul class="list-group list-group-flush">
                    <li>โรงเรียนศรีเทพบาล</li>
                    <li>โรงเรียนจัตุรัสวิยาคาร</li>
                    <li>โรงเรียนกองทัพบกอุปถัมภ์ ช่างกล ขส.ทบ</li>
                </ul>
            </div>

            <!-- Motto and Hobbies -->
            <div class="tab-pane fade" id="hobbies" role="tabpanel" aria-labelledby="hobbies-tab">
                <h5>คติประจำใจ</h5>
                <blockquote class="blockquote">
                    <p class="mb-0">gg Gz</p>
                </blockquote>
                <h5>งานอดิเรก</h5>
                <p>เล่นหมากรุก บาร์เทนเดอร์</p>
            </div>

            <!-- Career Interest -->
            <div class="tab-pane fade" id="career" role="tabpanel" aria-labelledby="career-tab">
                <h5>นักศึกษาเลือกเรียนสาขานี้เพราะอะไร? เรียนจบอยากทำอาชีพอะไร?</h5>
                <p>เลือกสาขา IT เพราะชอบ จบไปอยากทำอาชีพโปรแกรมเมอร์</p>
            </div>
        </div>
    </div>
</body>
</html>
