<?php
/* *** No Copyright for Education (Free to Use and Edit) *** */
# PHP 7.1.1 | MySQL 5.7.17 | phpMyAdmin 4.6.6 | by appserv-win32-8.6.0.exe
# Created by Mr.Earn SURIYACHAY | ComSci | KMUTNB | Bangkok | Apr 2018

// Ensure the keyword is set
if (isset($_GET['keyword'])) {
    $keyword = $_GET['keyword'];

    // Establishing connection to the database
    require('connect.php');

    if ($conn === false) {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    // Using prepared statement to prevent SQL injection
    // Assuming the correct column name is 'emp_name'
    $sql = "SELECT * FROM tb_d5_67 WHERE f_name LIKE ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("ERROR: Could not prepare query: $sql. " . $conn->error);
    }

    $param = "%{$keyword}%";
    $stmt->bind_param('s', $param);

    // Executing the query and checking for errors
    if ($stmt->execute()) {
        $result = $stmt->get_result();
    } else {
        die("Error executing query: " . $stmt->error);
    }
} else {
    die("Keyword is not set.");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Search Results</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
        body{
            display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: url(23r.jpg) no-repeat;
    background-size: cover;
    background-position: center;
}
  </style>
</head>

<body> 
<h2>Search Results</h2>
    <table class="table table-bordered">
    <thead class="table-dark">
        <tr>
            <th width="50">
                <div align="center">No</div>
            </th>
            <th width="100">
                <div align="center">รหัสนักศึกษา</div>
            </th>
            <th width="100">
                <div align="center">คำนำหน้า</div>
            </th>
            <th width="100">
                <div align="center">ชื่อ</div>
            </th>
            <th width="100">
                <div align="center">สกุล</div>
            </th>
            <th width="100">
                <div align="center">ชื่อเล่น</div>
            </th>
            <th width="100">
                <div align="center">เพศ</div>
            </th>
            <th width="100">
                <div align="center">เบอร์</div>
            </th>
            <th width="100">
                <div align="center">อีเมล</div>
            </th>
            <th width="100">
                <div align="center">แผกนวิชา</div>
            </th>
            <th width="100">
                <div align="center">profile</div>
            </th>
        </tr>
        </thead>
        <?php
        $i = 1;
        while ($objResult = $result->fetch_assoc()) {
        ?>
            <tr>
                <td>
                    <div align="center"><?php echo htmlspecialchars($i); ?></div>
                </td>
                <td><?php echo htmlspecialchars($objResult["std_id"]); ?></td>
                <td><?php echo htmlspecialchars($objResult["n_title"]); ?></td>
                <td><?php echo htmlspecialchars($objResult["f_name"]); ?></td>
                <td><?php echo htmlspecialchars($objResult["l_name"]); ?></td>
                <td><?php echo htmlspecialchars($objResult["n_name"]); ?></td>
                <td><?php echo htmlspecialchars($objResult["sex"]); ?></td>
                <td><?php echo htmlspecialchars($objResult["number"]); ?></td>
                <td><?php echo htmlspecialchars($objResult["e_mail"]); ?></td>
                <td><?php echo htmlspecialchars($objResult["DepartmentID"]); ?></td>
                <td align="center"><a href="<?php echo $objResult["profile_link"]; ?>"><button type="button" class="btn btn-outline-info">Profile</button></a></td>
            </tr>
        <?php
            $i++;
        }
        ?>
    </table>
    <div style="text-align: center;">
  <a  href="index2.php" class="btn btn-outline-dark">Back</a>
  </div>
    <?php
    // Closing the statement and connection
    $stmt->close();
    $conn->close();
    ?>
</body>

</html>
