<!DOCTYPE html>
<html lang="th">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>ประวัติส่วนตัว</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php
    // เชื่อมต่อฐานข้อมูล
    require('connect.php');

    // ดึงค่า std_id จาก URL
    $std_id = isset($_GET['std_id']) ? $_GET['std_id'] : '';

    if ($std_id) {
        // สร้างตัวแปร SQL และเตรียมคำสั่ง SQL
        $sql = "SELECT * FROM tb_d5_67 WHERE std_id = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("s", $std_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $objResult = $result->fetch_assoc();

            if ($objResult) {
                // Debugging output to ensure data is fetched correctly
                echo '<!-- Debug Info: ' . print_r($objResult, true) . ' -->';

                // Convert the image data to base64
                $imageData = base64_encode($objResult['image_data']);
                $backgroundData = isset($objResult['background_data']) ? base64_encode($objResult['background_data']) : null;
                $reason = htmlspecialchars($objResult['reason'], ENT_QUOTES, 'UTF-8');
                if ($backgroundData) {
                    echo '<style>
                        body {
                            background: url("data:image/jpeg;base64,' . $backgroundData . '") no-repeat center center fixed;
                            background-size: cover;
                        }
                    </style>';
                }
            }
            $stmt->close();
        }
    }
    $conn->close();
    ?>
</head>
<body>
    <h1 class="text-info">ประวัติส่วนตัว</h1>
    <?php if (isset($objResult)): ?>
        <img src="data:image/jpeg;base64,<?php echo $imageData; ?>" alt="Image description">
        <h1 class="text-dark">ประวัติส่วนตัวของฉัน</h1>
        <h2 class="text-primary">ชื่อ-สกุล:  "<?php echo htmlspecialchars($objResult['f_name'] . " . $objResult['l_name'], ENT_QUOTES, 'UTF-8'); ?></h2>
        <h2 class="text-primary">แผนก: <?php echo htmlspecialchars($objResult['DepartmentID'], ENT_QUOTES, 'UTF-8'); ?></h2>
        <h2 class="text-primary">อายุ: <?php echo htmlspecialchars($objResult['age'], ENT_QUOTES, 'UTF-8'); ?> ปี</h2>
        <h2 class="text-primary">ชื่อเล่น: <?php echo htmlspecialchars($objResult['n_name'], ENT_QUOTES, 'UTF-8'); ?></h2>
        <h2 class="text-primary">เกี่ยวกับฉัน: ส่วนสูง : <?php echo htmlspecialchars($objResult['height'], ENT_QUOTES, 'UTF-8'); ?> mm นํ้าหนัก: <?php echo htmlspecialchars($objResult['weight'], ENT_QUOTES, 'UTF-8'); ?> kg</h2>
        <h1 class="text-dark">ที่อยู่ปัจจุบัน</h1>
        <h2 class="text-warning"><?php echo htmlspecialchars($objResult['add'], ENT_QUOTES, 'UTF-8'); ?></h2>
        <h1 class="text-dark">ช่องทางการติดต่อ</h1>
        <h2 class="text-primary">gmail: <?php echo htmlspecialchars($objResult['e_mail'], ENT_QUOTES, 'UTF-8'); ?></h2>
        <h2 class="text-primary">facebook: <?php echo htmlspecialchars($objResult['facebook'], ENT_QUOTES, 'UTF-8'); ?></h2>
        <h2 class="text-primary">เบอร์โทรศัพท์: <?php echo htmlspecialchars($objResult['number'], ENT_QUOTES, 'UTF-8'); ?></h2>
        <h1 class="text-dark">ข้อมูลส่วนตัว</h1>
        <h2 class="text-primary">ชื่อบิดา: <?php echo htmlspecialchars($objResult['father_name'], ENT_QUOTES, 'UTF-8'); ?> อายุ: <?php echo htmlspecialchars($objResult['father_age'], ENT_QUOTES, 'UTF-8'); ?> ปี</h2>
        <h2 class="text-secondary">อาชีพ: <?php echo htmlspecialchars($objResult['father_job'], ENT_QUOTES, 'UTF-8'); ?> เบอร์โทรศัพท์: <?php echo htmlspecialchars($objResult['father_number'], ENT_QUOTES, 'UTF-8'); ?></h2>
        <h2 class="text-primary">ชื่อมารดา: <?php echo htmlspecialchars($objResult['mother_name'], ENT_QUOTES, 'UTF-8'); ?> อายุ: <?php echo htmlspecialchars($objResult['mother_age'], ENT_QUOTES, 'UTF-8'); ?> ปี</h2>
        <h2 class="text-secondary">อาชีพ: <?php echo htmlspecialchars($objResult['mother_job'], ENT_QUOTES, 'UTF-8'); ?> เบอร์โทรศัพท์: <?php echo htmlspecialchars($objResult['mother_number'], ENT_QUOTES, 'UTF-8'); ?></h2>
        <h1 class="text-dark">ประวัติศึกษา</h1>
        <h2 class="text-primary">จบจากโรงเรียน: <?php echo htmlspecialchars($objResult['school'], ENT_QUOTES, 'UTF-8'); ?> เกรดเฉลี่ย: <?php echo htmlspecialchars($objResult['gpa'], ENT_QUOTES, 'UTF-8'); ?></h2>
        <h1 class="text-dark">คติประจำใจ</h2>
        <h2 class="text-primary"><?php echo htmlspecialchars($objResult['motto'], ENT_QUOTES, 'UTF-8'); ?></h2>
        <h1 class="text-dark">งานอดิเรก</h1>
        <h2 class="text-primary"><?php echo htmlspecialchars($objResult['hobby'], ENT_QUOTES, 'UTF-8'); ?></h2>
        <h1 class="text-dark">เหตุผลที่เลือกเรียนสาขานี้</h1>
        <h2 class="text-primary"><?php echo $reason; ?></h2>
    <?php else: ?>
        <p class="text-danger">ไม่พบข้อมูล</p>
    <?php endif; ?>
</body>
</html>
