<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title> SURIYA </title>
      
</head>
<body style="background-image: url(yy.jpg);">

<h1 style="color: aliceblue;"> ประวัติส่วนตัว </h1>
<img src="436226906_420838740743259_931229596940089539_n.jpg" alt="Trulli" width="100" height="150" >

<p> 

      <h2 style="color: rgb(182, 206, 229);"> ชื่อ-สกุล: นาย วัชรพงศ์ แขมคำ </h2>
      <h2 style="color: rgb(182, 206, 229);"> ชื่อเล่น: นิว </h2>
      <h2 style="color: rgb(182, 206, 229);"> อายุ: 18 </h2>
      <h2 style="color: rgb(182, 206, 229);"> กรุ๊ปเลือด: B </h2>
      <h2 style="color: rgb(182, 206, 229);"> วันเกิด: 10/12/2548 </h2>
      <h2 style="color: rgb(182, 206, 229);"> ที่อยู่: 33/2 บ.ม่วง หมู่7 ต.บ้านเล่า อ.เมือง จ.ชัยภูมิ </h2>
      <h2 style="color: rgb(182, 206, 229);"> เกี่ยวกับฉัน: เป็นคนดีที่สุดในห้องนิสัยค่อนข้างกวนส้นเท้านิดหน่อย </h2>
      <h1 style="color: aliceblue;"> ช่องทางการติดต่อ </h1>
      <h2 style="color: rgb(182, 206, 229);"> E-mail>: 2548news@gmail.com </h2>
      <h2 style="color: rgb(182, 206, 229);"> Facebook: Watcharapong kheamkham  </h2>
      <h2 style="color: rgb(182, 206, 229);"> ID-line: n-ew-s2548 </h2>
      <h2 style="color: rgb(182, 206, 229);"> Phon number: 0955560390 </h2>
      <h1 style="color: aliceblue;"> ข้อมูลส่วนตัว </h1>
      <h2 style="color: rgb(182, 206, 229);"> ชื่อบิดา: บุญมา แขมคำ อายุ:-ปี อาชีพ:พนักงานบริษัท เบอร์:- </h2>
      <h2 style="color: rgb(182, 206, 229);"> ชื่อมารดา: ณิชนันท์ ภิญโญดม อายุ:-ปี อาชีพ:พนักงานบริษัท เบอร์:- </h2>
      <h1 style="color: aliceblue;"> ประวัติการศึกษา </h1>
      <h2 style="color: rgb(182, 206, 229);"> อนุบาล: โรงเรียนชุมชนวัดทับมา </h2>
      <h2 style="color: rgb(182, 206, 229);"> ประถม: โรงเรียนสุนทรวัฒนา </h2>
      <h2 style="color: rgb(182, 206, 229);"> ม.ต้น: โรงเรียนเมืองพญาแลวิทยา </h2>
      <h2 style="color: rgb(182, 206, 229);"> ม.ปลาย: โรงเรียนเมืองพญาแลวิทยา </h2>
      <h2 style="color: rgb(182, 206, 229);"> คติประจำใจ: บทเรียนของใจคืออย่ารักใครมากกว่าตัวเอง </h2>
      <h2 style="color: rgb(182, 206, 229);"> งานอดิเรก: 1.อ่านนิยาย2.แต่งเพลง </h2>
      <h2 style="color: aliceblue;"> เลือกสาขานี้เพราะออะไร? </h2>
      <h2 style="color: rgb(182, 206, 229);"> อยากเป็นProgrammer </h2>

</p>

</body>
</html>