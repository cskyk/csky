<?php
require('connect.php');
$std_id = isset($_GET['std_id']) ? $_GET['std_id'] : '';

$sql = "SELECT * FROM tb_d5_67 WHERE std_id = '" . $std_id . "'";
$objQuery = mysqli_query($conn, $sql) or die("Error Query [" . $sql . "]");
$objResult = mysqli_fetch_array($objQuery);
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <title>รายละเอียด</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <style>
     body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url(5.jpg) no-repeat;
            background-size: cover;
            background-position: center;
     }
     h2 {
      margin-top: 0;
      text-align: center;
      font-size: 1.8em;
      border-bottom: 2px solid #fff;
      padding-bottom: 10px;
    }
    .container {
        width: 420px;
        background: transparent;
        border: 2px solid rgba(255, 255, 255, .2);
        backdrop-filter: blur(9px);
        color: #fff;
        border-radius: 12px;
        padding: 30px 40px;
    }
    h2 {
      text-align: center;
    }
    .profile {
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>รายละเอียดนักศึกษา</h2>
    <div class="profile">
      <p><strong>รหัสนักศึกษา:</strong> <?php echo $objResult["std_id"]; ?></p>
      <p><strong>คำนำหน้า:</strong> <?php echo $objResult["n_title"]; ?></p>
      <p><strong>ชื่อ:</strong> <?php echo $objResult["f_name"]; ?></p>
      <p><strong>สกุล:</strong> <?php echo $objResult["l_name"]; ?></p>
      <p><strong>ชื่อเล่น:</strong> <?php echo $objResult["n_name"]; ?></p>
      <p><strong>เพศ:</strong> <?php echo $objResult["sex"]; ?></p>
      <p><strong>เบอร์:</strong> <?php echo $objResult["number"]; ?></p>
      <p><strong>อีเมล:</strong> <?php echo $objResult["e_mail"]; ?></p>
      <p><strong>แผกนวิชา:</strong> <?php echo $objResult["DepartmentID"]; ?></p>
      <!-- Add more fields if necessary -->
    </div>
    <div style="text-align: center;">
  <a  href="index2.php" class="btn btn-outline-dark">Back</a>
  </div>
  </div>
</body>
</html>
<?php
mysqli_close($conn);
?>
