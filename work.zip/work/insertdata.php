<?php
require('connect.php');

// Retrieve input values
$std_id = $_REQUEST['std_id'];
$n_title = $_REQUEST['n_title'];
$f_name = $_REQUEST['f_name'];
$l_name = $_REQUEST['l_name'];
$n_name = $_REQUEST['n_name'];
$sex = $_REQUEST['sex'];
$number = $_REQUEST['number'];
$e_mail = $_REQUEST['e_mail'];
$DepartmentID = $_REQUEST['DepartmentID'];

// Prepare the SQL statement
$stmt = $conn->prepare("INSERT INTO tb_d5_67 (std_id, DepartmentID, n_title, f_name, l_name, n_name, sex, number, e_mail) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

// Check if the statement was prepared successfully
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

// Bind parameters
$stmt->bind_param("sssssssss", $std_id, $DepartmentID, $n_title, $f_name, $l_name, $n_name, $sex, $number, $e_mail);

// Execute the statement
if ($stmt->execute()) {
    echo "เพิ่มข้อมูเสร็จแล้ว";
} else {
    echo "Error: " . $stmt->error;
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
