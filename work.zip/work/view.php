<?php
require('connect.php');
$std_id = isset($_GET['std_id']) ? $_GET['std_id'] : '';

$sql = "SELECT * FROM tb_d5_67 WHERE std_id = '" . $std_id . "'";
$objQuery = mysqli_query($conn, $sql) or die("Error Query [" . $sql . "]");
$objResult = mysqli_fetch_array($objQuery);
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <title>รายละเอียด</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 20px;
    }
    .container {
      max-width: 800px;
      margin: auto;
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    h2 {
      text-align: center;
    }
    .profile {
      text-align: left;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>รายละเอียดนักศึกษา</h2>
    <div class="profile">
      <p><strong>รหัสนักศึกษา:</strong> <?php echo $objResult["std_id"]; ?></p>
      <p><strong>คำนำหน้า:</strong> <?php echo $objResult["n_title"]; ?></p>
      <p><strong>ชื่อ:</strong> <?php echo $objResult["f_name"]; ?></p>
      <p><strong>สกุล:</strong> <?php echo $objResult["l_name"]; ?></p>
      <p><strong>ชื่อเล่น:</strong> <?php echo $objResult["n_name"]; ?></p>
      <p><strong>เพศ:</strong> <?php echo $objResult["sex"]; ?></p>
      <p><strong>เบอร์:</strong> <?php echo $objResult["number"]; ?></p>
      <p><strong>อีเมล:</strong> <?php echo $objResult["e_mail"]; ?></p>
      <p><strong>แผกนวิชา:</strong> <?php echo $objResult["DepartmentID"]; ?></p>
      <!-- Add more fields if necessary -->
    </div>
    <a href="index2.php">Back to Search</a>
  </div>
</body>
</html>
<?php
mysqli_close($conn);
?>
