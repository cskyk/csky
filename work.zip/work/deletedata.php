<?php

$delete_ID  = $_REQUEST['std_id'];

require('connect.php');

$sql = '
    DELETE FROM tb_d5_67
    WHERE std_id = ' . $delete_ID . ';
    ';

$objQuery = mysqli_query($conn, $sql);
if ($objQuery) {
    echo "ลบข้อมูลของ " . $delete_ID . "เรียบร้อย";
} else {
    echo "Error : Delete";
}

mysqli_close($conn); // ปิดฐานข้อมูล
echo "<br><br>";
?>