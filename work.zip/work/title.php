<?php
require('connect.php'); // เรียกใช้ไฟล์ connect.php ที่มีการเชื่อมต่อฐานข้อมูล

$sql = 'SELECT * FROM tb_d5_67 LIMIT 10'; // คำสั่ง SQL ในการดึงข้อมูลสูงสุด 10 คน
$result = mysqli_query($conn, $sql); // เรียกใช้คำสั่ง SQL

// ตรวจสอบว่า Query ทำงานสำเร็จหรือไม่
if (!$result) {
    die('Query Failed: ' . mysqli_error($conn)); // แสดงข้อผิดพลาดถ้า Query ไม่สำเร็จ
}

$num_rows = mysqli_num_rows($result); // นับจำนวนแถวในผลลัพธ์
if ($num_rows > 0) {
    echo "จำนวนข้อมูลทั้งหมด: " . $num_rows; // แสดงจำนวนข้อมูล
} else {
    echo "EMPTY DATA"; // ถ้าไม่มีข้อมูลแสดงข้อความนี้
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">ข้อมูลนักศึกษา</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>รหัสนักศึกษา</th>
                <th>คำนำหน้า</th>
                <th>ชื่อ</th>
                <th>สกุล</th>
                <th>ชื่อเล่น</th>
                <th>เพศ</th>
                <th>แผกนวิชา</th>
                <th>โปรไฟล์</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            while ($objResult = mysqli_fetch_assoc($result)) { // ดึงข้อมูลจากตัวแปร $result
                echo "<tr>";
                echo "<td>" . htmlspecialchars($no) . "</td>"; // แสดงลำดับข้อมูล
                echo "<td>" . htmlspecialchars($objResult["std_id"]) . "</td>"; // แสดงรหัสนักศึกษา
                echo "<td>" . htmlspecialchars($objResult["n_title"]) . "</td>"; // แสดงคำนำหน้า
                echo "<td>" . htmlspecialchars($objResult["f_name"]) . "</td>"; // แสดงชื่อ
                echo "<td>" . htmlspecialchars($objResult["l_name"]) . "</td>"; // แสดงสกุล
                echo "<td>" . htmlspecialchars($objResult["n_name"]) . "</td>"; // แสดงชื่อเล่น
                echo "<td>" . htmlspecialchars($objResult["sex"]) . "</td>"; // แสดงเพศ
                echo "<td>" . htmlspecialchars($objResult["DepartmentID"]) . "</td>"; // แสดงแผกนวิชา
                // แสดงลิงก์โปรไฟล์ที่คลิกได้
                echo '<td><a href="' . htmlspecialchars($objResult["profile_link"]) . '" class="btn btn-primary" target="_blank">Profile</a></td>';
                echo "</tr>";
                $no++; // เพิ่มค่า $no ทีละ 1
            }

            $no = 2;
            while ($objResult = mysqli_fetch_assoc($result)) { // ดึงข้อมูลจากตัวแปร $result
                echo "<tr>";
                echo "<td>" . htmlspecialchars($no) . "</td>"; // แสดงลำดับข้อมูล
                echo "<td>" . htmlspecialchars($objResult["std_id"]) . "</td>"; // แสดงรหัสนักศึกษา
                echo "<td>" . htmlspecialchars($objResult["n_title"]) . "</td>"; // แสดงคำนำหน้า
                echo "<td>" . htmlspecialchars($objResult["f_name"]) . "</td>"; // แสดงชื่อ
                echo "<td>" . htmlspecialchars($objResult["l_name"]) . "</td>"; // แสดงสกุล
                echo "<td>" . htmlspecialchars($objResult["n_name"]) . "</td>"; // แสดงชื่อเล่น
                echo "<td>" . htmlspecialchars($objResult["sex"]) . "</td>"; // แสดงเพศ
                echo "<td>" . htmlspecialchars($objResult["DepartmentID"]) . "</td>"; // แสดงแผกนวิชา
                // แสดงลิงก์โปรไฟล์ที่คลิกได้
                echo '<td><a href="frank loo/frank.php' . htmlspecialchars($objResult["profile_link"]) . '" class="btn btn-primary" target="_blank">Profile</a></td>';
                echo "</tr>";
                $no++; // เพิ่มค่า $no ทีละ 1
            }

            $no = 3;
            while ($objResult = mysqli_fetch_assoc($result)) { // ดึงข้อมูลจากตัวแปร $result
                echo "<tr>";
                echo "<td>" . htmlspecialchars($no) . "</td>"; // แสดงลำดับข้อมูล
                echo "<td>" . htmlspecialchars($objResult["std_id"]) . "</td>"; // แสดงรหัสนักศึกษา
                echo "<td>" . htmlspecialchars($objResult["n_title"]) . "</td>"; // แสดงคำนำหน้า
                echo "<td>" . htmlspecialchars($objResult["f_name"]) . "</td>"; // แสดงชื่อ
                echo "<td>" . htmlspecialchars($objResult["l_name"]) . "</td>"; // แสดงสกุล
                echo "<td>" . htmlspecialchars($objResult["n_name"]) . "</td>"; // แสดงชื่อเล่น
                echo "<td>" . htmlspecialchars($objResult["sex"]) . "</td>"; // แสดงเพศ
                echo "<td>" . htmlspecialchars($objResult["DepartmentID"]) . "</td>"; // แสดงแผกนวิชา
                // แสดงลิงก์โปรไฟล์ที่คลิกได้
                echo '<td><a href="' . htmlspecialchars($objResult["profile_link"]) . '" class="btn btn-primary" target="_blank">Profile</a></td>';
                echo "</tr>";
                $no++; // เพิ่มค่า $no ทีละ 1
            }

            $no = 4;
            while ($objResult = mysqli_fetch_assoc($result)) { // ดึงข้อมูลจากตัวแปร $result
                echo "<tr>";
                echo "<td>" . htmlspecialchars($no) . "</td>"; // แสดงลำดับข้อมูล
                echo "<td>" . htmlspecialchars($objResult["std_id"]) . "</td>"; // แสดงรหัสนักศึกษา
                echo "<td>" . htmlspecialchars($objResult["n_title"]) . "</td>"; // แสดงคำนำหน้า
                echo "<td>" . htmlspecialchars($objResult["f_name"]) . "</td>"; // แสดงชื่อ
                echo "<td>" . htmlspecialchars($objResult["l_name"]) . "</td>"; // แสดงสกุล
                echo "<td>" . htmlspecialchars($objResult["n_name"]) . "</td>"; // แสดงชื่อเล่น
                echo "<td>" . htmlspecialchars($objResult["sex"]) . "</td>"; // แสดงเพศ
                echo "<td>" . htmlspecialchars($objResult["DepartmentID"]) . "</td>"; // แสดงแผกนวิชา
                // แสดงลิงก์โปรไฟล์ที่คลิกได้
                echo '<td><a href="' . htmlspecialchars($objResult["profile_link"]) . '" class="btn btn-primary" target="_blank">Profile</a></td>';
                echo "</tr>";
                $no++; // เพิ่มค่า $no ทีละ 1
            }

            $no = 5;
            while ($objResult = mysqli_fetch_assoc($result)) { // ดึงข้อมูลจากตัวแปร $result
                echo "<tr>";
                echo "<td>" . htmlspecialchars($no) . "</td>"; // แสดงลำดับข้อมูล
                echo "<td>" . htmlspecialchars($objResult["std_id"]) . "</td>"; // แสดงรหัสนักศึกษา
                echo "<td>" . htmlspecialchars($objResult["n_title"]) . "</td>"; // แสดงคำนำหน้า
                echo "<td>" . htmlspecialchars($objResult["f_name"]) . "</td>"; // แสดงชื่อ
                echo "<td>" . htmlspecialchars($objResult["l_name"]) . "</td>"; // แสดงสกุล
                echo "<td>" . htmlspecialchars($objResult["n_name"]) . "</td>"; // แสดงชื่อเล่น
                echo "<td>" . htmlspecialchars($objResult["sex"]) . "</td>"; // แสดงเพศ
                echo "<td>" . htmlspecialchars($objResult["DepartmentID"]) . "</td>"; // แสดงแผกนวิชา
                // แสดงลิงก์โปรไฟล์ที่คลิกได้
                echo '<td><a href="nut/nut.php'. htmlspecialchars($objResult["profile_link"]) . '" class="btn btn-primary" target="_blank">Profile</a></td>';
                echo "</tr>";
                $no++; // เพิ่มค่า $no ทีละ 1
            }

            $no = 1;
            while ($objResult = mysqli_fetch_assoc($result)) { // ดึงข้อมูลจากตัวแปร $result
                echo "<tr>";
                echo "<td>" . htmlspecialchars($no) . "</td>"; // แสดงลำดับข้อมูล
                echo "<td>" . htmlspecialchars($objResult["std_id"]) . "</td>"; // แสดงรหัสนักศึกษา
                echo "<td>" . htmlspecialchars($objResult["n_title"]) . "</td>"; // แสดงคำนำหน้า
                echo "<td>" . htmlspecialchars($objResult["f_name"]) . "</td>"; // แสดงชื่อ
                echo "<td>" . htmlspecialchars($objResult["l_name"]) . "</td>"; // แสดงสกุล
                echo "<td>" . htmlspecialchars($objResult["n_name"]) . "</td>"; // แสดงชื่อเล่น
                echo "<td>" . htmlspecialchars($objResult["sex"]) . "</td>"; // แสดงเพศ
                echo "<td>" . htmlspecialchars($objResult["DepartmentID"]) . "</td>"; // แสดงแผกนวิชา
                // แสดงลิงก์โปรไฟล์ที่คลิกได้
                echo '<td><a href="' . htmlspecialchars($objResult["profile_link"]) . '" class="btn btn-primary" target="_blank">Profile</a></td>';
                echo "</tr>";
                $no++; // เพิ่มค่า $no ทีละ 1
            }

            $no = 1;
            while ($objResult = mysqli_fetch_assoc($result)) { // ดึงข้อมูลจากตัวแปร $result
                echo "<tr>";
                echo "<td>" . htmlspecialchars($no) . "</td>"; // แสดงลำดับข้อมูล
                echo "<td>" . htmlspecialchars($objResult["std_id"]) . "</td>"; // แสดงรหัสนักศึกษา
                echo "<td>" . htmlspecialchars($objResult["n_title"]) . "</td>"; // แสดงคำนำหน้า
                echo "<td>" . htmlspecialchars($objResult["f_name"]) . "</td>"; // แสดงชื่อ
                echo "<td>" . htmlspecialchars($objResult["l_name"]) . "</td>"; // แสดงสกุล
                echo "<td>" . htmlspecialchars($objResult["n_name"]) . "</td>"; // แสดงชื่อเล่น
                echo "<td>" . htmlspecialchars($objResult["sex"]) . "</td>"; // แสดงเพศ
                echo "<td>" . htmlspecialchars($objResult["DepartmentID"]) . "</td>"; // แสดงแผกนวิชา
                // แสดงลิงก์โปรไฟล์ที่คลิกได้
                echo '<td><a href="' . htmlspecialchars($objResult["profile_link"]) . '" class="btn btn-primary" target="_blank">Profile</a></td>';
                echo "</tr>";
                $no++; // เพิ่มค่า $no ทีละ 1
            }

            $no = 1;
            while ($objResult = mysqli_fetch_assoc($result)) { // ดึงข้อมูลจากตัวแปร $result
                echo "<tr>";
                echo "<td>" . htmlspecialchars($no) . "</td>"; // แสดงลำดับข้อมูล
                echo "<td>" . htmlspecialchars($objResult["std_id"]) . "</td>"; // แสดงรหัสนักศึกษา
                echo "<td>" . htmlspecialchars($objResult["n_title"]) . "</td>"; // แสดงคำนำหน้า
                echo "<td>" . htmlspecialchars($objResult["f_name"]) . "</td>"; // แสดงชื่อ
                echo "<td>" . htmlspecialchars($objResult["l_name"]) . "</td>"; // แสดงสกุล
                echo "<td>" . htmlspecialchars($objResult["n_name"]) . "</td>"; // แสดงชื่อเล่น
                echo "<td>" . htmlspecialchars($objResult["sex"]) . "</td>"; // แสดงเพศ
                echo "<td>" . htmlspecialchars($objResult["DepartmentID"]) . "</td>"; // แสดงแผกนวิชา
                // แสดงลิงก์โปรไฟล์ที่คลิกได้
                echo '<td><a href="' . htmlspecialchars($objResult["profile_link"]) . '" class="btn btn-primary" target="_blank">Profile</a></td>';
                echo "</tr>";
                $no++; // เพิ่มค่า $no ทีละ 1
            }

            $no = 1;
            while ($objResult = mysqli_fetch_assoc($result)) { // ดึงข้อมูลจากตัวแปร $result
                echo "<tr>";
                echo "<td>" . htmlspecialchars($no) . "</td>"; // แสดงลำดับข้อมูล
                echo "<td>" . htmlspecialchars($objResult["std_id"]) . "</td>"; // แสดงรหัสนักศึกษา
                echo "<td>" . htmlspecialchars($objResult["n_title"]) . "</td>"; // แสดงคำนำหน้า
                echo "<td>" . htmlspecialchars($objResult["f_name"]) . "</td>"; // แสดงชื่อ
                echo "<td>" . htmlspecialchars($objResult["l_name"]) . "</td>"; // แสดงสกุล
                echo "<td>" . htmlspecialchars($objResult["n_name"]) . "</td>"; // แสดงชื่อเล่น
                echo "<td>" . htmlspecialchars($objResult["sex"]) . "</td>"; // แสดงเพศ
                echo "<td>" . htmlspecialchars($objResult["DepartmentID"]) . "</td>"; // แสดงแผกนวิชา
                // แสดงลิงก์โปรไฟล์ที่คลิกได้
                echo '<td><a href="' . htmlspecialchars($objResult["profile_link"]) . '" class="btn btn-primary" target="_blank">Profile</a></td>';
                echo "</tr>";
                $no++; // เพิ่มค่า $no ทีละ 1
            }

            $no = 1;
            while ($objResult = mysqli_fetch_assoc($result)) { // ดึงข้อมูลจากตัวแปร $result
                echo "<tr>";
                echo "<td>" . htmlspecialchars($no) . "</td>"; // แสดงลำดับข้อมูล
                echo "<td>" . htmlspecialchars($objResult["std_id"]) . "</td>"; // แสดงรหัสนักศึกษา
                echo "<td>" . htmlspecialchars($objResult["n_title"]) . "</td>"; // แสดงคำนำหน้า
                echo "<td>" . htmlspecialchars($objResult["f_name"]) . "</td>"; // แสดงชื่อ
                echo "<td>" . htmlspecialchars($objResult["l_name"]) . "</td>"; // แสดงสกุล
                echo "<td>" . htmlspecialchars($objResult["n_name"]) . "</td>"; // แสดงชื่อเล่น
                echo "<td>" . htmlspecialchars($objResult["sex"]) . "</td>"; // แสดงเพศ
                echo "<td>" . htmlspecialchars($objResult["DepartmentID"]) . "</td>"; // แสดงแผกนวิชา
                // แสดงลิงก์โปรไฟล์ที่คลิกได้
                echo '<td><a href="' . htmlspecialchars($objResult["profile_link"]) . '" class="btn btn-primary" target="_blank">Profile</a></td>';
                echo "</tr>";
                $no++; // เพิ่มค่า $no ทีละ 1
            }
            ?>
        </tbody>
    </table>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
